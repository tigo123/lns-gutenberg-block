=== LNS Gutenberg Block ===
Contributors:      LeNamSite
Tags:              block, gutenberg
Requires at least: 6.6
Tested up to:      6.8.1
Requires PHP:      7.4
Stable tag:        1.1
License:           GPL-2.0-or-later
License URI:       https://www.gnu.org/licenses/gpl-2.0.html

https://lenamsite.com &#39;s 2025.

== Description ==

Gutenberg Blocks used for your website. Developed by LeNamSite

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/` directory
2. Open Terminal at plugin folder
3. Run command: npm i
4. Run command: npm run build-all
5. Active this plugin

== Changelog ==

= 1.1 2025-06-26 =
* Fix bug
* Add: conclusion block

= 1.0 2025-06-25 =
* Release with blockquote block