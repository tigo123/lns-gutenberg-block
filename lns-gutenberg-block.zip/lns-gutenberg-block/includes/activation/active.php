<?php
namespace LNSGB\Activation;

if ( !defined( 'ABSPATH' ) )
    die( 'Invalid request.' );

final class Active
{
    // constructor
    public function __construct()
    {
    }

}
new Active();